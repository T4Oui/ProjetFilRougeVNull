package modele;

public class TestJNA {
	
	public static void main(String[] args) {
		LibraryTexteMoteur libraryMoteur = LibraryTexteMoteur.INSTANCE;
		libraryMoteur.indexation_texte();
	}
}
